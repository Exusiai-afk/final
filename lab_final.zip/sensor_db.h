/**
 * \author Minghao Chen
 */


#ifndef _SENSOR_DB_H_
#define _SENSOR_DB_H_

#include <stdio.h>
#include <stdlib.h>
#include "config.h"

void *storage_mgr_run(void *buffer);

#endif /* _SENSOR_DB_H_ */